AEROLITE Android project

1. Extract this folder on your phone (Files app).
2. In Code on the Go (or AndroidIDE) open an existing project and choose the AEROLITE folder.
3. Wait for the sync (first time needs internet), then build the APK and install it.

To update the app page later: replace app/src/main/assets/index.html and build again.
