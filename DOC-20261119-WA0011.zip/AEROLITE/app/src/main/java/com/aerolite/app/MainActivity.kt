package com.aerolite.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pageReady = false
    private var waiting: Pair<String, String>? = null
    private var pendingText = ""

    // The page calls these two functions to use the phone's own file screens.
    private inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, text: String) {
            runOnUiThread { startSave(name, text) }
        }

        @JavascriptInterface
        fun openFile() {
            runOnUiThread { startOpen() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                waiting?.let { sendToPage(it.first, it.second) }
                waiting = null
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        openFromIntent(intent)
    }

    // Tapping an .aero file in a file manager can open it here.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        openFromIntent(intent)
    }

    private fun openFromIntent(i: Intent?) {
        val uri = i?.data
        if (i?.action == Intent.ACTION_VIEW && uri != null) readUri(uri)
    }

    // The system "Save as" screen: choose any folder or make a new one.
    private fun startSave(name: String, text: String) {
        pendingText = text
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, name)
        startActivityForResult(i, 1)
    }

    // The system file picker: choose a saved program.
    private fun startOpen() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, 2)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode == 1) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use {
                    it.write(pendingText.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not save the file", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == 2) {
            readUri(uri)
        }
    }

    private fun readUri(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return
            var name = "program.aero"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (col >= 0 && c.moveToFirst()) name = c.getString(col)
            }
            if (pageReady) sendToPage(name, text) else waiting = Pair(name, text)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open that file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendToPage(name: String, text: String) {
        web.evaluateJavascript(
            "window.aeroLoad(" + JSONObject.quote(name) + "," + JSONObject.quote(text) + ")", null
        )
    }
}
